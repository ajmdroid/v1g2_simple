import{l as o,a as r}from"../chunks/BC96MVB-.js";export{o as load_css,r as start};
