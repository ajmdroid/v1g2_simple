import{l as o,a as r}from"../chunks/DGG78Ilp.js";export{o as load_css,r as start};
